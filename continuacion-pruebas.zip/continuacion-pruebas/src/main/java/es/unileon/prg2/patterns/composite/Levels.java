package es.unileon.prg2.patterns.composite;

public enum Levels {
    COMPOSITE,
    LEAF
}
