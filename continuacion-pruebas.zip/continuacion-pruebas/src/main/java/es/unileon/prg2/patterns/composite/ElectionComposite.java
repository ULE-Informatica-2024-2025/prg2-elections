package es.unileon.prg2.patterns.composite;

import es.unileon.prg2.patterns.decorator.ConcreteResults;
import es.unileon.prg2.patterns.decorator.Results;
import es.unileon.prg2.patterns.handler.Handler;
import es.unileon.prg2.patterns.handler.Name;
import es.unileon.prg2.patterns.iterator.Iterator;
import es.unileon.prg2.patterns.iterator.VectorAggregate;
import es.unileon.prg2.patterns.observer.Observer;
import es.unileon.prg2.patterns.strategy.DoNothingStrategy;
import es.unileon.prg2.patterns.strategy.CountingStrategy;

public abstract class ElectionComposite implements ElectionComponent {

	protected Name name;
	protected VectorAggregate<ElectionComponent> components;
	protected int seats;
	protected Results results;
	protected CountingStrategy strategy;
	protected VectorAggregate<Observer> observers;

	public ElectionComposite(Handler name) {
		this.name = new Name(name);
		this.components = new VectorAggregate<ElectionComponent>();
		this.seats = 0;
		this.strategy = new DoNothingStrategy();
		this.observers = new VectorAggregate<Observer>();
	}

	public Handler getId() {
		return new Name(this.name);
	}

	public String getNames() {
		StringBuffer result = new StringBuffer();

		for (ElectionComponent c : this.components) {
			result.append(c.getNames());
		}

		return result.toString();
	}

	public Results getResults() {
		return this.results;
	}

	public Results recount() {
		if (this.results != null) {
			Results totalChildren = new ConcreteResults();
			for (ElectionComponent c : this.components) {
				totalChildren.add(c.recount());
			}

			this.update(this.strategy.assignSeats(totalChildren, this.seats));
		}

		// Siempre que se recuenta se notifica a los posibles observadores
		this.noti();

		// Se devuelve una copia de los resultados, para que nadie pueda modificarlos
		return new ConcreteResults(this.results);
	}

	public void update(Results results) {
		if (this.results == null) {
			this.results = new ConcreteResults(results);
		} else {
			this.results.empty();
			this.results.add(results);
		}
	}

	public boolean add(ElectionComponent component) {

		// ¡Falta comprobar si this puede añadir a component!
		// ¡Falta comprobar que no se haya añadido previamente este componente!

		// ¡Falta copiar los resultados de this al nuevo hijo si el hijo no tiene!
		// ¡O añadir los resultados del hijo a this si sí que tiene!

		return this.components.add(component);
	}

	public boolean remove(ElectionComponent component) {
		boolean found;

		found = this.components.remove(component);
		if (!found) {
			Iterator<ElectionComponent> iterator = this.components.createIterator();
			while ((!found) && (iterator.hasMoreElements())) {
				found = iterator.currentElement().remove(component);
				iterator.nextElement();
			}
		}
		return found;
	}

	public ElectionComponent search(Handler id) {
		ElectionComponent found;

		found = null;
		if (id.compareTo(this.name) == 0) {
			found = this;
		} else {
			Iterator<ElectionComponent> iterator = this.components.createIterator();
			while ((found == null) && (iterator.hasMoreElements())) {
				found = iterator.currentElement().search(id);
				iterator.nextElement();
			}
		}
		return found;
	}

	public void set(CountingStrategy strategy) {
		this.strategy = strategy;
	}

	public void decorate(Results results) {
		this.results = results;
	}

	public void removeDecorators() {
		this.results = new ConcreteResults(this.results);
	}

	public void attach(Observer observer) {
		this.observers.add(observer);
	}

	public void detach() {
		this.observers.clear();
	}

	public void noti() {
		Iterator<Observer> iterator = this.observers.createIterator();
		while (iterator.hasMoreElements()) {
			iterator.currentElement().update();
			iterator.nextElement();
		}
	}

	public String toString() {
		StringBuffer result = new StringBuffer();

		for (ElectionComponent c : this.components) {
			result.append(c.toString());
		}

		return result.toString();
	}

	@Override
	public Iterator<ElectionComponent> createIterator() {
		return this.components.createIterator();
	}

	@Override
	public Iterator<ElectionComponent> createIterator(String type) {
		return this.components.createIterator(type);
	}
}
