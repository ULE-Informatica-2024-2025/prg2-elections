package es.unileon.prg2.patterns.decorator;

import es.unileon.prg2.elections.Parties;
import es.unileon.prg2.elections.Party;

public class ColorDecorator extends Decorator {

    public ColorDecorator(Results results) {
        super(results);
    }

    public String toString() {
        String resultsToDecorate = this.results.toString();

        StringBuilder output = new StringBuilder();

        String[] linesToDecorate = resultsToDecorate.split("\n");

        Parties parties = this.results.getParties();

        for (String lineToDecorate : linesToDecorate) {
            Party party = this.extractParty(lineToDecorate, parties);

            if (party != null) {
                output.append(party.getColor().toString());
                output.append("\t");
                output.append(lineToDecorate);
                output.append("\n");
            }
            else {
                output.append(lineToDecorate);
                output.append("\n");
            }
        }

        return output.toString();
    }

    private Party extractParty(String line, Parties parties) {
        String[] fields = line.split("\t");

        Party party = null;

        int i = 0;
        while (i < fields.length && party == null) {
            if (parties.getParty(fields[i]) != null) {
                party = parties.getParty(fields[i]);
            }
            i++;
        }

        return party;
    }

}
