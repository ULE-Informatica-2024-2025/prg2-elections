package es.unileon.prg2.patterns.builder;

import es.unileon.prg2.patterns.composite.*;
import es.unileon.prg2.patterns.iterator.*;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

public class TreeElectionBuilder {

    private Tree tree;
    private TreeItem root;

    public TreeElectionBuilder(Tree tree) {
        this.tree = tree;
        this.root = new TreeItem(tree, SWT.NONE);
        this.root.setText("ESPAÑA");
    }

    public void buildTreeFromComposite(CompositeNode compositeRoot) {
        this.root.removeAll(); // Limpiar el árbol gráfico actual
        traverseAndBuild(this.root, compositeRoot);
    }

    private void traverseAndBuild(TreeItem parent, ElectionComponent component) {
        TreeItem current = new TreeItem(parent, SWT.NONE);
        current.setText(component.getId().toString());

        if (component instanceof ElectionComposite) {
            Iterator<ElectionComponent> iterator = ((ElectionComposite) component).createIterator();
            while (iterator.hasNext()) {
                traverseAndBuild(current, iterator.next());
            }
        }
    }

    public Tree getTree() {
        return this.tree;
    }
}
