package es.unileon.prg2.patterns.decorator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import es.unileon.prg2.elections.Parties;
import es.unileon.prg2.elections.Party;
import es.unileon.prg2.patterns.iterator.Iterator;

public class ConcreteResults implements Results {

    private int empties;
    private int nulls;
    private HashMap<Party, Integer> votes;
    private HashMap<Party, Integer> seats;

    public ConcreteResults() {
        this.empties = 0;
        this.nulls = 0;
        this.votes = new HashMap<Party, Integer>();
        this.seats = new HashMap<Party, Integer>();
    }

    public ConcreteResults(Parties parties) {
        this();
        for (Iterator<Party> iterator = parties.createIterator(); iterator.hasMoreElements(); iterator.nextElement()) {
            this.votes.put(iterator.currentElement(), 0);
            this.seats.put(iterator.currentElement(), 0);
        }
    }

    public ConcreteResults(Results anotherResults) {
        this.empties = anotherResults.getEmpties();
        this.nulls = anotherResults.getNulls();
        this.votes = new HashMap<Party, Integer>();
        this.seats = new HashMap<Party, Integer>();

        Parties parties = anotherResults.getParties();

        Iterator<Party> iterator = parties.createIterator();
        while(iterator.hasMoreElements()) {
            this.votes.put(iterator.currentElement(), anotherResults.getVotes(iterator.currentElement()));
            this.seats.put(iterator.currentElement(), anotherResults.getSeats(iterator.currentElement()));
            iterator.nextElement();
        }
    }

    public Parties getParties() {
        Parties parties = new Parties();

        for(Party party : this.votes.keySet()) {
            parties.add(party);
        }

        return parties;
    }

    public int getEmpties() {
        return this.empties;
    }

    public void setEmpties(int empties) {
        this.empties = empties;
    }

    public int getNulls() {
        return this.nulls;
    }

    public void setNulls(int nulls) {
        this.nulls = nulls;
    }

    public int getVotes(Party party) {
        return this.votes.get(party);
    }

    public void setVotes(Party party, int votes) {
        this.votes.put(party, votes);
    }

    public int getSeats(Party party) {
        return this.seats.get(party);
    }

    public void setSeats(Party party, int seats) {
        this.seats.put(party, seats);
    }

    public void empty() {
        for (Party i : this.votes.keySet()) {
            this.votes.put(i, 0);
            this.seats.put(i, 0);
        }

        this.empties = 0;
        this.nulls = 0;
    }

    public void add(Results results) {
        Parties parties = results.getParties();

        Iterator<Party> iterator = parties.createIterator();

        int prevVotes, prevSeats;
        while(iterator.hasMoreElements()) {
            prevVotes = 0;
            prevSeats = 0;

            if(this.votes.containsKey(iterator.currentElement())) {
                prevVotes = this.getVotes(iterator.currentElement());
                prevSeats = this.getSeats(iterator.currentElement());
            }

            this.votes.put(iterator.currentElement(), prevVotes + results.getVotes(iterator.currentElement()));
            this.seats.put(iterator.currentElement(), prevSeats + results.getSeats(iterator.currentElement()));

            iterator.nextElement();
        }

        this.empties = this.empties + results.getEmpties();
        this.nulls = this.nulls + results.getNulls();
    }

    public String toString() {
        StringBuilder output = new StringBuilder();

        List<Map.Entry<Party, Integer>> sorted = new ArrayList<>(this.votes.entrySet());
        sorted.sort(Map.Entry.comparingByValue());
        Collections.reverse(sorted);

        for (Map.Entry<Party, Integer> entry : sorted) {
            output.append(entry.getKey().getName() + "\t" + entry.getValue());
            output.append("\t(" + this.seats.get(entry.getKey()) + " seats)\n");
        }
        output.append("Empties: " + this.empties);
        output.append("\n");
        output.append("Nulls: " + this.nulls);

        return output.toString();
    }

}
