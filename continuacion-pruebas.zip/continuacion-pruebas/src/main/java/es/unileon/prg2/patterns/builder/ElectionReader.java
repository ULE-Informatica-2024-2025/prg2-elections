package es.unileon.prg2.patterns.builder;

import es.unileon.prg2.patterns.composite.ElectionException;

public class ElectionReader {

    private Source source;

    public ElectionReader(String filePath) throws ElectionException {
        this.source = new Source(filePath);
    }

    public boolean hasMoreLines() {
        return this.source.hasNext();
    }

    public String getNextLine(){
        return this.source.getNext();
    }

}
