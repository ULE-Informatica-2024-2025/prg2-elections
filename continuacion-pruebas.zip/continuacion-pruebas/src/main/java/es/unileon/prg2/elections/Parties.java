package es.unileon.prg2.elections;

import es.unileon.prg2.patterns.handler.Handler;
import es.unileon.prg2.patterns.handler.Name;
import es.unileon.prg2.patterns.iterator.Iterator;
import es.unileon.prg2.patterns.iterator.VectorAggregate;

public class Parties {

    private VectorAggregate<Party> parties;

    public Parties(){
        this.parties = new VectorAggregate<Party>();
    }

    public int getSize() {
        return this.parties.size();
    }

    public Party get(int index) {
        return this.parties.elementAt(index);
    }

    public boolean add(Party party) {
        boolean added = false;

        if(!this.contains(party)) {
            this.parties.add(party);
            added = true;
        }

        return added;
    }

    public Party getParty(String partyName) {
        Party party = null;
        String partyWanted = partyName;
        Iterator<Party> iterator = this.createIterator();

        while(party == null && iterator.hasMoreElements()) {
            if(iterator.currentElement().getName().compareTo(partyWanted) == 0) {
                party = iterator.currentElement();
            }
            iterator.nextElement();
        }

        return party;
    }

    public boolean contains(Party party) {
        return this.getParty(party.getName().toString()) != null;
    }

    public Iterator<Party> createIterator(){
        return this.parties.createIterator();
    }

    public String toString(){
        StringBuilder output = new StringBuilder();
        for (Party party : parties) {
            output.append(party.toString() + "\n");
        }
        return output.toString();
    }

}
