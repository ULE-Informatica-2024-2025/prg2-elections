package es.unileon.prg2.patterns.iterator;

import java.util.NoSuchElementException;

import es.unileon.prg2.elections.Party;

public class ListIterator<T> implements Iterator<T> {

    private Aggregate<T> aggregate;
    private int current;

    public ListIterator(Aggregate<T> aggregate) {
        this.aggregate = aggregate;
        current = 0;
    }

    public void firstElement() {
        current = 0;
    }

    public void nextElement() {
        current = current + 1;
    }

    public boolean hasMoreElements() {
        return current < aggregate.getSize();
    }

    public T currentElement() {
        return aggregate.get(current);
    }

    @Override
    public boolean hasNext() {
        return hasMoreElements();
    }

    @Override
    public T next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        T element = aggregate.get(current);
        nextElement();
        return element;
    }

}
