package es.unileon.prg2.patterns.builder;

public class Name {

}
