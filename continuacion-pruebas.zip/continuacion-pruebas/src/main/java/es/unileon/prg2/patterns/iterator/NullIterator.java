package es.unileon.prg2.patterns.iterator;

public class NullIterator<T> implements Iterator<T> {

    public NullIterator() {
    }

    public void firstElement() {
    }

    public void nextElement() {
    }

    public boolean hasMoreElements() {
        return false;
    }

    public T currentElement() {
        return null;
    }

    @Override
    public boolean hasNext() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'hasNext'");
    }

    @Override
    public T next() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'next'");
    }
}
