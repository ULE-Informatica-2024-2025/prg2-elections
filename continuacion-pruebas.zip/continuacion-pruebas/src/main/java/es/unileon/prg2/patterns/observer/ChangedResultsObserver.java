package es.unileon.prg2.patterns.observer;

import es.unileon.prg2.elections.controllers.ElectionsController;
import es.unileon.prg2.patterns.composite.ElectionComponent;

public class ChangedResultsObserver implements Observer {

    private ElectionComponent observedNode;
    private ElectionsController controller;

    public ChangedResultsObserver(ElectionComponent observedNode, ElectionsController controller) {
        this.observedNode = observedNode;
        this.controller = controller;
    }

    @Override
    public void update() {
        // TO DO
    }
}
