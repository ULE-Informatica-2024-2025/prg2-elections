package es.unileon.prg2.elections;


public class Municipality {
    private String nombre;
    private Parties partidos;
    private int censo;

    public Municipality(String nombre, Parties partidos, int censo) {
        this.nombre = nombre;
        this.partidos = partidos;
        this.censo = censo;
    }

    // Getters and Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Parties getPartidos() {
        return partidos;
    }

    public void setPartidos(Parties partidos) {
        this.partidos = partidos;
    }

    public int getCenso() {
        return censo;
    }

    public void setCenso(int censo) {
        this.censo = censo;
    }
}
