package es.unileon.prg2.patterns.observer;

public interface Observer {

    void update();

}
