package es.unileon.prg2.elections.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

import es.unileon.prg2.elections.ElectionException;
import es.unileon.prg2.elections.Elections;
import es.unileon.prg2.elections.view.EditVotesPopup;
import es.unileon.prg2.elections.view.ElectionsView;
import es.unileon.prg2.patterns.builder.ElectionBuilder;
import es.unileon.prg2.patterns.builder.TreeElectionBuilder;
import es.unileon.prg2.patterns.command.*;
import es.unileon.prg2.patterns.decorator.Results;

public class ElectionsController {

    private Elections elections;
    private ElectionsView electionsView;
    private Tree tree;

    private Command getResultsCommand, decorateColorCommand, decoratePercentageCommand, getResultsToEditCommand,
            saveResultsCommand, removeDecoratorsCommand, attachNewLeaderObserverCommand,
            attachChangedResultsObserverCommand, removeObserversCommand;

    private Results editedResults;

    private Map<String, Table> appliedObservers;

    public ElectionsController(Elections elections, Display display) {
        this.elections = elections;
        this.electionsView = new ElectionsView(display, this);

        this.getResultsCommand = new CommandGetResults(this.elections);
        this.decorateColorCommand = new CommandDecorateColor(this.elections);
        this.decoratePercentageCommand = new CommandDecoratePercentage(this.elections);
        this.getResultsToEditCommand = new CommandGetResultsToEdit(this.elections);
        this.saveResultsCommand = new CommandSaveResults(this.elections);
        this.removeDecoratorsCommand = new CommandRemoveDecorators(this.elections);
        this.attachNewLeaderObserverCommand = new CommandAttachNewLeaderObserver(this.elections);
        this.attachChangedResultsObserverCommand = new CommandAttachChangedResultsObserver(this.elections);
        this.removeObserversCommand = new CommandRemoveObservers(this.elections);

        this.appliedObservers = new HashMap<String, Table>();

        this.handleTreeClick();
    }

    public void bind(Tree tree) {
        this.tree = tree;
        this.populate(this.tree);
        TreeItem firstItem = tree.getItem(0);
        tree.setSelection(new TreeItem[] { firstItem });
        tree.addListener(SWT.Selection, event -> handleTreeClick());
    }

    private void handleTreeClick() {
        this.getResultsCommand.execute(this);
    }

    public String getSelectedNode() throws ElectionException {
        if (this.tree.getSelectionCount() <= 0) {
            throw new ElectionException("No selected nodes");
        }
        return this.tree.getSelection()[0].getData().toString();
    }

    public void showResults(String results) {
        this.electionsView.showResults(results);
    }

    private void populate(Tree tree) {
        ElectionBuilder builder = (ElectionBuilder) new TreeElectionBuilder(tree);

        String[] lines = this.elections.getNames().split("\n");

        String[] splittedLine;
        for (String line : lines) {
            splittedLine = line.split(": ");
            splittedLine[0] = splittedLine[0].trim();

            switch (splittedLine[0]) {
                case "Leaf":
                    builder.buildLeaf(splittedLine[1]);
                    break;
            }
        }
    }

    public void bind(Combo combo, Button button) {
        button.addListener(SWT.Selection, event -> handleComboButtonClick(combo, button));
    }

    private void handleComboButtonClick(Combo combo, Button button) {
        switch (button.getData().toString()) {
            case "decorate":
                this.decorate(combo);
                break;
            case "attach":
                this.attach(combo);
                break;

        }
    }

    private void decorate(Combo combo) {
        switch (combo.getText()) {
            case "Color":
                this.decorateColorCommand.execute(this);
                break;
            case "Porcentaje":
                this.decoratePercentageCommand.execute(this);
                break;
        }

        this.getResultsCommand.execute(this);
    }

    private void attach(Combo combo) {
        String key = "";

        switch (combo.getText()) {
            case "Cambios en los resultados":
                try {
                    key = this.elections.search(this.getSelectedNode()).getId().toString() + "-changed-results";
                } catch (ElectionException e) {
                    System.out.println(e.getMessage());
                }

                if (!this.appliedObservers.containsKey(key)) {
                    this.appliedObservers.put(key, this.electionsView.addTable(key));
                    this.attachChangedResultsObserverCommand.execute(this);
                }
                break;
            case "Nuevo partido en cabeza":
                try {
                    key = this.elections.search(this.getSelectedNode()).getId().toString() + "-new-leader";
                } catch (ElectionException e) {
                    System.out.println(e.getMessage());
                }

                this.appliedObservers.put(key, this.electionsView.addTable(key));
                this.attachNewLeaderObserverCommand.execute(this);
                break;
        }
    }

    public void bind(Button button) {
        button.addListener(SWT.Selection, event -> handleButtonClick(button));
    }

    private void handleButtonClick(Button button) {
        switch (button.getData().toString()) {
            case "edit":
                this.getResultsToEditCommand.execute(this);
                break;
            case "dedecorate":
                this.removeDecoratorsCommand.execute(this);
                this.getResultsCommand.execute(this);
                break;
            case "detach":
                this.removeObserversCommand.execute(this);
                this.removeObservers();
                break;
        }
    }

    private void removeObservers() {
        String partialKey = "";
        try {
            partialKey = this.elections.search(this.getSelectedNode()).getId().toString();
        } catch (ElectionException e) {
            System.out.println(e.getMessage());
        }

        List<String> keysToRemove = new ArrayList<String>();

        for (Map.Entry<String, Table> table : this.appliedObservers.entrySet()) {
            if (table.getKey().contains(partialKey)) {
                this.electionsView.removeTable(table.getValue());
                keysToRemove.add(table.getKey());
            }
        }

        for (String keyToRemove : keysToRemove) {
            this.appliedObservers.remove(keyToRemove);
        }
    }

    public void showPopup(Results results) {
        new EditVotesPopup(this.electionsView, this, results);
    }

    // public void bind(Button button, Results results) {
    // button.addListener(SWT.Selection, event -> handleButtonClick(button,
    // results));
    // }

    // private void handleButtonClick(Button button, Results results) {
    // // For now there's only one button passing results (save from the popup)
    // this.editedResults = results;
    // this.saveResultsCommand.execute(this);
    // this.getResultsCommand.execute(this);
    // }

    public Results getEditedResults() {
        return this.editedResults;
    }

    public void openUI() {
        this.electionsView.open();
    }

    public boolean isUIDisposed() {
        return this.electionsView.isDisposed();
    }

    public void requestRecount() {
        this.elections.recount();
        this.getResultsCommand.execute(this);
    }

    public void updateResults(String table, String results) {
        this.electionsView.showResults(this.appliedObservers.get(table), results);
    }

}
