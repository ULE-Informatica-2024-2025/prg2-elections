package es.unileon.prg2.patterns.command;

import es.unileon.prg2.elections.ElectionException;
import es.unileon.prg2.elections.Elections;
import es.unileon.prg2.elections.controllers.ElectionsController;
import es.unileon.prg2.patterns.observer.NewLeaderObserver;

public class CommandAttachNewLeaderObserver implements Command {

    private Elections receiver;

    public CommandAttachNewLeaderObserver(Elections receiver) {
        this.receiver = receiver;
    }

    public void execute(ElectionsController invoker) {
        String nodeToBeObserved = "";
        try {
            nodeToBeObserved = invoker.getSelectedNode();
            this.receiver.attach(nodeToBeObserved, new NewLeaderObserver(this.receiver.search(nodeToBeObserved), invoker));
        } catch (ElectionException e) {
            System.out.println(e.getMessage());
        }

        invoker.updateResults(this.receiver.search(nodeToBeObserved).getId().toString() + "-new-leader", this.receiver.search(nodeToBeObserved).toString());
    }
}
