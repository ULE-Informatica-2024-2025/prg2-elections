package es.unileon.prg2.patterns.command;

import es.unileon.prg2.elections.ElectionException;
import es.unileon.prg2.elections.Elections;
import es.unileon.prg2.elections.controllers.ElectionsController;
import es.unileon.prg2.patterns.decorator.ColorDecorator;

public class CommandDecorateColor implements Command {

    private Elections receiver;

    public CommandDecorateColor(Elections receiver) {
        this.receiver = receiver;
    }

    public void execute(ElectionsController invoker) {
        try {
            String nodeToDecorate = invoker.getSelectedNode();
            this.receiver.decorate(nodeToDecorate,
                    new ColorDecorator(this.receiver.getResults(nodeToDecorate)));
        } catch (ElectionException e) {
            System.out.println(e.getMessage());
        }
    }
}
