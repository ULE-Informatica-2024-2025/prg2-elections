package es.unileon.prg2.elections;


import java.util.List;
import es.unileon.prg2.elections.Party;

public class Province {
    private String name;
    private List<Municipality> municipalities;
    private Parties parties;
    private int totalCensus;
    private int numberOfSeats;

    public Province(String name, List<Municipality> municipalities, Parties parties, int totalCensus, int numberOfSeats) {
        this.name = name;
        this.municipalities = municipalities;
        this.parties = parties;
        this.totalCensus = totalCensus;
        this.numberOfSeats = numberOfSeats;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Municipality> getMunicipalities() {
        return municipalities;
    }

    public void setMunicipalities(List<Municipality> municipalities) {
        this.municipalities = municipalities;
    }

    public Parties getParties() {
        return parties;
    }

    public void setParties(Parties parties) {
        this.parties = parties;
    }

    public int getTotalCensus() {
        return totalCensus;
    }

    public void setTotalCensus(int totalCensus) {
        this.totalCensus = totalCensus;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

}





