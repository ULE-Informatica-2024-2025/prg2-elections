package es.unileon.prg2.patterns.handler;

public class Name implements Handler {

	private String id;

	public Name(String id) {
		this.id = id;
	}

	public Name(Handler id) {
		this.id = id.toString();
	}

	@Override
	public int compareTo(Handler another) {
		return this.id.compareTo(another.toString());
	}

	public String toString() {
		return this.id;
	}

	public Handler asHandler() {
        return this;
    }

}
