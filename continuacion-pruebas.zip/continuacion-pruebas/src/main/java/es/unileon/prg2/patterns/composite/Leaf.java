package es.unileon.prg2.patterns.composite;

import es.unileon.prg2.patterns.decorator.ConcreteResults;
import es.unileon.prg2.patterns.decorator.Results;
import es.unileon.prg2.patterns.handler.Handler;
import es.unileon.prg2.patterns.handler.Name;
import es.unileon.prg2.patterns.iterator.Iterator;
import es.unileon.prg2.patterns.iterator.NullIterator;
import es.unileon.prg2.patterns.iterator.VectorAggregate;
import es.unileon.prg2.patterns.observer.Observer;
import es.unileon.prg2.patterns.strategy.DoNothingStrategy;
import es.unileon.prg2.patterns.strategy.CountingStrategy;

public class Leaf implements ElectionComponent {

	private final Levels LEVEL = Levels.LEAF;

	private Handler name;
	private Results results;
	private CountingStrategy strategy;
	private VectorAggregate<Observer> observers;

	public Leaf(String name) {
		this.name = new Name(name);
		this.strategy = new DoNothingStrategy();
		this.observers = new VectorAggregate<Observer>();
	}

	public Leaf(Handler name) {
		this(name.toString());
	}

	public Handler getId() {
		return new Name(this.name);
	}

	public Levels getLevel() {
		return this.LEVEL;
	}

	public String getNames() {
		return "\t\tLeaf: " + this.name + "\n";
	}

	public Results getResults() {
		return this.results;
	}

	public Results recount() {
		if (this.results != null) {
			this.update(this.strategy.assignSeats(this.results, 0));
		}

		this.noti();

		return new ConcreteResults(this.results);
	}

	public void update(Results results) {
		if (this.results == null) {
			this.results = new ConcreteResults();
		}

		this.results.empty();
		this.results.add(results);
	}

	public boolean add(ElectionComponent component) throws ElectionException {
		throw new ElectionException("Nothing can be added to a polling station");
	}

	public boolean remove(ElectionComponent component) {
		return false;
	}

	public ElectionComponent search(Handler id) {
		if (id.compareTo(this.name) == 0)
			return this;
		return null;
	}

	public void set(CountingStrategy strategy) {
		this.strategy = strategy;
	}

	public void decorate(Results results) {
		this.results = results;
	}

	public void removeDecorators() {
		this.results = new ConcreteResults(this.results);
	}

	public void attach(Observer observer) {
		this.observers.add(observer);
	}

	public void detach() {
		this.observers.clear();
	}

	public void noti() {
		Iterator<Observer> iterator = this.observers.createIterator();
		while (iterator.hasMoreElements()) {
			iterator.currentElement().update();
			iterator.nextElement();
		}
	}

	public String toString() {
		return "\t\tLeaf: " + this.name + "\n" + this.results.toString() + "\n";
	}

	@Override
	public Iterator<ElectionComponent> createIterator() {
		return new NullIterator<>();
	}

	@Override
	public Iterator<ElectionComponent> createIterator(String type) {
		return new NullIterator<>();
	}

}
