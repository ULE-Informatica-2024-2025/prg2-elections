package es.unileon.prg2.patterns.decorator;

import es.unileon.prg2.elections.Parties;
import es.unileon.prg2.elections.Party;

public interface Results {

    Parties getParties();

    int getEmpties();

    void setEmpties(int empties);

    int getNulls();

    void setNulls(int nulls);

    int getVotes(Party party);

    void setVotes(Party party, int votes);

    int getSeats(Party party);

    void setSeats(Party party, int seats);

    void empty();

    void add(Results results);

    String toString();

}
