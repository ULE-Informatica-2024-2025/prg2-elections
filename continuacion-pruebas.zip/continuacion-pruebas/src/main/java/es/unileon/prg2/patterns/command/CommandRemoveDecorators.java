package es.unileon.prg2.patterns.command;

import es.unileon.prg2.elections.ElectionException;
import es.unileon.prg2.elections.Elections;
import es.unileon.prg2.elections.controllers.ElectionsController;

public class CommandRemoveDecorators implements Command {

    private Elections receiver;

    public CommandRemoveDecorators(Elections receiver) {
        this.receiver = receiver;
    }

    public void execute(ElectionsController invoker) {
        try {
            String nodeToRemoveDecorators = invoker.getSelectedNode();
            this.receiver.removeDecorators(nodeToRemoveDecorators);
        } catch (ElectionException e) {
            System.out.println(e.getMessage());
        }
    }
}
