package es.unileon.prg2.patterns.decorator;

import es.unileon.prg2.elections.Parties;
import es.unileon.prg2.elections.Party;

public abstract class Decorator implements Results {

    protected Results results;

    public Decorator(Results results) {
        this.results = results;
    }

    public Parties getParties() {
        return this.results.getParties();
    }

    public int getEmpties() {
        return this.results.getEmpties();
    }

    public void setEmpties(int empties) {
        this.results.setEmpties(empties);
    }

    public int getNulls() {
        return this.results.getNulls();
    }

    public void setNulls(int nulls) {
        this.results.setNulls(nulls);
    }

    public int getVotes(Party party) {
        return this.results.getVotes(party);
    }

    public void setVotes(Party party, int votes) {
        this.results.setVotes(party, votes);
    }

    public int getSeats(Party party){
        return this.results.getSeats(party);
    }

    public void setSeats(Party party, int seats) {
        this.results.setSeats(party, seats);
    }

    public void empty() {
        this.results.empty();
    }

    public void add(Results results) {
        this.results.add(results);
    }
}
