package es.unileon.prg2.patterns.composite;

import es.unileon.prg2.patterns.handler.Handler;

public class CompositeNode extends ElectionComposite {

	private final Levels LEVEL = Levels.COMPOSITE;

	public CompositeNode(Handler id) {
		super(id);
	}
	
	public Levels getLevel() {
		return this.LEVEL;
	}

	public String getNames() {
        return "\tComposite node: " + this.name + "\n" + super.getNames();
    }
    
    public String toString() {
        return "\tComposite node: " + this.name.toString() + "\n" + this.results.toString();
    }

    public ElectionComponent[] getChildren() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getChildren'");
    }

	
}
