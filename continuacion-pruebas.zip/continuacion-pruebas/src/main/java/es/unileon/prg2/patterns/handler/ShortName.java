package es.unileon.prg2.patterns.handler;

public class ShortName implements Handler {

	private String id;

	public ShortName(String id) throws MalformedHandlerException {
		StringBuffer message;

		message = new StringBuffer();
		if (id.length() > 2) {
			message.append("The length of the identifier should be less than 2.\n"
					+ id + " is not valid.");
		} else if ( id.length() == 0 ){
			message.append("The identifier can not be an empty one.\n");
		} else if ( ( id.length() == 1 ) && ( !Character.isLetter(id.charAt(0)) ) ){
			message.append("The identifier can only include letters.\n"			
					+ id + " is not valid.");
		} else if ( ( id.length() == 2 ) && 
				( !Character.isLetter(id.charAt(0)) || !Character.isLetter(id.charAt(1)) ) ){
			message.append("The identifier can only include letters.\n"			
					+ id + " is not valid.");
		} else {
			this.id = id;
		}
		if (message.length() != 0)
			throw new MalformedHandlerException(message.toString());
	}

	public ShortName(Handler id) throws MalformedHandlerException {
		// I DO NOT REPEAT CODE IN HERE!!!
		this(id.toString());
	}

	@Override
	public int compareTo(Handler another) {
		return this.id.compareTo(another.toString());
	}

	public String toString() {
		return this.id;
	}

}
