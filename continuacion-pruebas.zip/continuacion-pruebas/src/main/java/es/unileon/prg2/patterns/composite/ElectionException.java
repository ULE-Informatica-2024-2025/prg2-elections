package es.unileon.prg2.patterns.composite;

public class ElectionException extends Exception {
	
	public ElectionException(String msg){
		super(msg);
	}

}
