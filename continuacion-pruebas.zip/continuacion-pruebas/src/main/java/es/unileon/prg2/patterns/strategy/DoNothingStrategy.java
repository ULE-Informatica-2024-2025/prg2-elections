package es.unileon.prg2.patterns.strategy;

import es.unileon.prg2.patterns.decorator.ConcreteResults;
import es.unileon.prg2.patterns.decorator.Results;

public class DoNothingStrategy implements CountingStrategy {

    @Override
    public Results assignSeats(Results results, int seats) {
        return new ConcreteResults(results);
    }

}
