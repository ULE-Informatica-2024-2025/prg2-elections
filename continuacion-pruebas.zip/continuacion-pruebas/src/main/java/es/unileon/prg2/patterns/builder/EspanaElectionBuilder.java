package es.unileon.prg2.patterns.builder;

import es.unileon.prg2.patterns.composite.*;
import es.unileon.prg2.patterns.handler.Name;
import es.unileon.prg2.elections.Province;
import es.unileon.prg2.elections.Municipality;
import es.unileon.prg2.elections.Parties;
import es.unileon.prg2.elections.Party;
import es.unileon.prg2.patterns.decorator.ConcreteResults;
import es.unileon.prg2.patterns.handler.Handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.eclipse.swt.widgets.Tree;

public class EspanaElectionBuilder implements ElectionBuilder {

    private CompositeNode root;

    public EspanaElectionBuilder(String rootName) {
        this.root = new CompositeNode(new Name(rootName));
    }

    public void buildTree(List<Province> provinces) {
        if (provinces == null || provinces.isEmpty()) {
            throw new IllegalArgumentException("La lista de provincias está vacía o es nula.");
        }

        for (Province province : provinces) {
            if (province == null) {
                System.err.println("Provincia nula encontrada.");
                continue;
            }

            String provinceName = province.getName();

            // Crear nodo compuesto para la provincia
            CompositeNode provinceNode = new CompositeNode(new Name(provinceName).asHandler());
            ConcreteResults provinceResults = new ConcreteResults(province.getParties());
            provinceNode.update(provinceResults);

            // Añadir partidos con votos y escaños dinámicos a través de Results
            List<Party> provinceParties = new ArrayList<>(province.getParties());
            for (Party party : provinceParties) {
                provinceResults.setVotes(party, provinceResults.getVotes(party)); // Mantener votos dinámicos
                provinceResults.setSeats(party, provinceResults.getSeats(party)); // Mantener escaños dinámicos
            }
            // Añadir municipios como nodos hoja
            if (province.getMunicipalities() != null) {
                for (Municipality municipality : province.getMunicipalities()) {
                    if (municipality == null) {
                        System.err.println("Municipio nulo en provincia: " + provinceName);
                        continue;
                    }

                    Leaf municipalityNode = new Leaf(new Name(municipality.getNombre()).asHandler());
                    ConcreteResults municipalityResults = new ConcreteResults(municipality.getPartidos());
                    municipalityNode.update(municipalityResults);

                    // Crear lista o colección de partidos en Municipality
                    for (Party party : convertToList(municipality.getPartidos())) {
                        municipalityResults.setVotes(party, municipalityResults.getVotes(party));
                        municipalityResults.setSeats(party, municipalityResults.getSeats(party));
                    }

                    try {
                        provinceNode.add(municipalityNode);
                    } catch (ElectionException e) {
                        System.err.println("Error al añadir municipio: " + municipality.getNombre() + " en provincia: "
                                + provinceName + ". Detalles: " + e.getMessage());
                    }
                }
            }

            try {
                root.add(provinceNode);
            } catch (ElectionException e) {
                System.err.println("Error al añadir provincia: " + provinceName + ". Detalles: " + e.getMessage());
            }
        }
    }

    @Override
    public CompositeNode getRoot() {
        return this.root;
    }

    private <T> List<T> convertToList(Collection<T> collection) {
        if (collection == null) {
            return Collections.emptyList();
        }
        return new ArrayList<>(collection);
    }

    public void integrateWithInterface(TreeElectionBuilder treeBuilder) {
        if (treeBuilder == null) {
            throw new IllegalArgumentException("TreeElectionBuilder no puede ser nulo.");
        }
        treeBuilder.buildTreeFromComposite(root);
    }

    @Override
    public void buildLeaf(String line) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'buildLeaf'");
    }

    @Override
    public Tree getTree() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getTree'");
    }
}
