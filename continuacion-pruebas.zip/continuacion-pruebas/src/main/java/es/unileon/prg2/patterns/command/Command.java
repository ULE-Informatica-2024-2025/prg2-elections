package es.unileon.prg2.patterns.command;

import es.unileon.prg2.elections.controllers.ElectionsController;

public interface Command {

    void execute(ElectionsController invoker);

}
