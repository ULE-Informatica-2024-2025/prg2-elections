package es.unileon.prg2.elections;

import es.unileon.prg2.patterns.builder.ElectionBuilder;
import es.unileon.prg2.patterns.builder.ElectionReader;
import es.unileon.prg2.patterns.builder.EspanaElectionBuilder;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.logging.Handler;

import es.unileon.prg2.elections.Parties;
import es.unileon.prg2.elections.Party;
import es.unileon.prg2.patterns.builder.EspanaElectionBuilder;
import es.unileon.prg2.patterns.composite.ElectionComponent;
import es.unileon.prg2.patterns.composite.ElectionException;
import es.unileon.prg2.patterns.decorator.Results;
import es.unileon.prg2.patterns.handler.Name;
import es.unileon.prg2.patterns.observer.Observer;

public class Elections {

    private ElectionComponent election;
    private Parties parties;

    public Elections(String root, String provinceSeatsPartiesFile, String pollingStationsFile)
            throws ElectionException {

        List<Province> provinces = leerCSV(pollingStationsFile, provinceSeatsPartiesFile);

        EspanaElectionBuilder electionsBuilder = new EspanaElectionBuilder("España");
        electionsBuilder.buildTree(provinces);

        this.election = electionsBuilder.getRoot();

        this.parties = this.election.getResults().getParties();
    }

    public static List<Province> leerCSV(String censoFilePath, String partidosFilePath) throws ElectionException {
        List<Province> provinces = new ArrayList<>();
        Map<String, Province> provinceMap = new HashMap<>();
    
        // Read census data
        try (BufferedReader censoReader = new BufferedReader(new FileReader(censoFilePath))) {
            String line = censoReader.readLine(); // Skip header
    
            while ((line = censoReader.readLine()) != null) {
                line = line.replaceAll(";+", ";").trim();
                if (line.isEmpty() || !line.contains(";")) {
                    System.err.println("Ignoring invalid or empty line in census file: " + line);
                    continue;
                }
    
                String[] parts = line.split(";");
                if (parts.length < 6) {
                    System.err.println("Invalid census data format, skipping line: " + line);
                    continue;
                }
    
                String provinceName = parts[0].trim();
                String municipalityName = parts[1].trim();
    
                int census;
                try {
                    census = Integer.parseInt(parts[5].trim());
                } catch (NumberFormatException e) {
                    System.err.println("Invalid census number, skipping line: " + line);
                    continue;
                }
    
                Province province = provinceMap.computeIfAbsent(provinceName, 
                    name -> new Province(name, new ArrayList<>(), new Parties(), 0, 0));
    
                Municipality municipality = province.getMunicipalities().stream()
                    .filter(m -> m.getNombre().equals(municipalityName))
                    .findFirst()
                    .orElseGet(() -> {
                        Municipality newMunicipality = new Municipality(municipalityName, new Parties(), census);
                        province.getMunicipalities().add(newMunicipality);
                        return newMunicipality;
                    });
    
                municipality.setCenso(municipality.getCenso() + census);
                province.setTotalCensus(province.getTotalCensus() + census);
            }
        } catch (IOException e) {
            throw new ElectionException("Error reading census file: " + e.getMessage());
        }
    
        // Read party data
        try (BufferedReader partidosReader = new BufferedReader(new FileReader(partidosFilePath))) {
            String line = partidosReader.readLine(); // Header includes parties
            if (line == null) {
                throw new ElectionException("Party file is empty or invalid.");
            }
    
            String[] headers = line.split(";"); // First row has party names starting from index 2
    
            while ((line = partidosReader.readLine()) != null) {
                line = line.replaceAll(";+", ";").trim(); // Normalize multiple delimiters to a single ";"
                if (line.isEmpty() || !line.contains(";")) {
                    System.err.println("Ignoring invalid or empty line in party file: " + line);
                    continue;
                }
    
                String[] parts = line.split(";");
    
                if (parts.length < 2) {
                    System.err.println("Invalid party data format, skipping line: " + line);
                    continue;
                }
    
                String provinceName = parts[0].trim();
                int seats;
                try {
                    seats = Integer.parseInt(parts[1].trim());
                } catch (NumberFormatException e) {
                    System.err.println("Invalid number of seats, skipping line: " + line);
                    continue;
                }
    
                Province province = provinceMap.get(provinceName);
                if (province == null) {
                    System.err.println("Province not found for line: " + line);
                    continue; // Skip if province not found in census data
                }
    
                province.setNumberOfSeats(seats);
    
                // Create Parties object for the province
                Parties provinceParties = new Parties();
                for (int i = 2; i < headers.length; i++) {
                    if (i >= parts.length || parts[i].isEmpty() || headers[i].isEmpty()) {
                        continue; // Skip empty columns or headers
                    }
                    String partyName = headers[i].trim();
                    System.out.println(partyName);
                    Color partyColor = ColorUtils.getPartyColor(partyName);
                    System.out.println(partyColor);
                    Party party = new Party(partyName, partyColor);
                    provinceParties.add(party);
                }
                province.setParties(provinceParties);
    
                // Assign parties to municipalities within the province using the updated iterator
                List<Municipality> municipalities = province.getMunicipalities();
                for (Municipality municipality : municipalities) {
                    Parties municipalityParties = new Parties();
    
                    es.unileon.prg2.patterns.iterator.Iterator<Party> provincePartiesIterator = provinceParties.createIterator();
                    while (provincePartiesIterator.hasNext()) {
                        Party provinceParty = provincePartiesIterator.next();
                        Party municipalityParty = new Party(provinceParty.getName(), provinceParty.getColor());
                        municipalityParties.add(municipalityParty);
                    }
                    municipality.setPartidos(municipalityParties);
                }
            }
        } catch (IOException e) {
            throw new ElectionException("Error reading party file: " + e.getMessage());
        }
    
        provinces.addAll(provinceMap.values());
        return provinces;
    }
    
    
    
    
    
    // Utility class for party color determination
    class ColorUtils {
        public static Color getPartyColor(String partyName) {
            switch (partyName.toLowerCase()) {
                case "pp":
                    return Color.BLUE;
                case "psoe":
                    return Color.RED;
                case "vox":
                    return Color.GREEN;
                case "podemos":
                    return Color.PINK;
                case "cs":
                    return Color.ORANGE;
                default:
                    return Color.GRAY;
            }
        }
    }
    
    

    public String getNames() {
        return this.election.getNames();
    }

    public ElectionComponent search(String node) {
        return this.election.search(new Name(node));
    }

    public void recount() {
        this.election.recount();
    }

    public void recount(String pollingStation, Results results) {
        ElectionComponent polligStationToUpdate = this.election.search(new Name(pollingStation));

        if (polligStationToUpdate != null) {
            polligStationToUpdate.update(results);
        }

        this.recount();
    }

    public Results getResults(String node) {
        return this.election.search(new Name(node)).getResults();
    }

    public void decorate(String node, Results decorator) {
        ElectionComponent nodeToDecorate = this.election.search(new Name(node));

        nodeToDecorate.decorate(decorator);
    }

    public void removeDecorators(String node) {
        this.election.search(new Name(node)).removeDecorators();
    }

    public void attach(String node, Observer observer) {
        this.election.search(new Name(node)).attach(observer);
    }

    public void detach(String node) {
        this.election.search(new Name(node)).detach();
    }

    public String getNodeToString(String node) {
        return this.election.search(new Name(node)).toString();
    }

    public String toString() {
        StringBuilder output = new StringBuilder();
        output.append(this.election.toString());
        output.append(this.parties.toString());

        return output.toString();
    }

}
