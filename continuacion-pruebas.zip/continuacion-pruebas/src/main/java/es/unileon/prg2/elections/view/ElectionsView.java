package es.unileon.prg2.elections.view;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Tree;

import es.unileon.prg2.elections.controllers.ElectionsController;

public class ElectionsView extends Shell {

    private Composite treeContainer, resultsContainer, observersContainer;
    private ScrolledComposite scrollableContainer;
    private Group selectionResultsGroup;
    private Table selectionResults;

    public ElectionsView(Display display, ElectionsController electionsController) {
        super(display);

        this.setSize(new Point(getShell().getDisplay().getPrimaryMonitor().getClientArea().width, 720));

        this.setLayout(new GridLayout(2, true));

        //////////////////////////////////////////////
        // TREE CONTAINER (LEFT SIDE OF THE WINDOW) //
        //////////////////////////////////////////////

        this.treeContainer = new Composite(this, SWT.NONE);
        this.treeContainer.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
        this.treeContainer.setLayout(new FillLayout());

        // TREE //
        //////////

        Tree tree = new Tree(this.treeContainer, SWT.BORDER);
        electionsController.bind(tree);

        /////////////////////////////////////////////////////////////
        // RESULTS AND ACTIONS CONTAINER (LEFT SIDE OF THE WINDOW) //
        /////////////////////////////////////////////////////////////

        this.resultsContainer = new Composite(this, SWT.NONE);
        this.resultsContainer.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
        this.resultsContainer.setLayout(new GridLayout());

        // SELECTION RESULTS GROUP //
        /////////////////////////////

        this.selectionResultsGroup = new Group(resultsContainer, SWT.NONE);
        this.selectionResultsGroup.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        this.selectionResultsGroup.setText("RESULTADOS DEL NODO SELECCIONADO");

        this.selectionResultsGroup.setLayout(new GridLayout());

        this.selectionResults = new Table(this.selectionResultsGroup, SWT.MULTI | SWT.BORDER | SWT.FULL_SELECTION);

        this.selectionResults.setLinesVisible(true);
        this.selectionResults.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

        // OBSERVERS RESULTS GROUP //
        /////////////////////////////

        Group observersGroup = new Group(resultsContainer, SWT.NONE);
        observersGroup.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
        observersGroup.setText("RESULTADOS DE LOS NODOS OBSERVADOS");
        observersGroup.setLayout(new FillLayout());

        this.scrollableContainer = new ScrolledComposite(observersGroup, SWT.NONE | SWT.V_SCROLL | SWT.H_SCROLL);
        this.scrollableContainer.setExpandHorizontal(true);
        this.scrollableContainer.setExpandVertical(true);

        this.observersContainer = new Composite(this.scrollableContainer, SWT.NONE);
        this.observersContainer.setLayout(new GridLayout());

        // ACTIONS GROUPS //
        ////////////////////

        Composite actionsContainer = new Composite(resultsContainer, SWT.NONE);
        actionsContainer.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        actionsContainer.setLayout(new GridLayout(3, true));

        Group decoratorsActions = new Group(actionsContainer, SWT.NONE);
        decoratorsActions.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
        decoratorsActions.setLayout(new GridLayout());
        decoratorsActions.setText("DECORADORES");

        Combo decoratorsCombo = new Combo(decoratorsActions, SWT.READ_ONLY);
        decoratorsCombo.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        decoratorsCombo.setItems("Porcentaje", "Color");
        decoratorsCombo.select(0);

        Button applyDecoratorBtn = new Button(decoratorsActions, SWT.NONE);
        applyDecoratorBtn.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        applyDecoratorBtn.setText("Aplicar decorador");
        applyDecoratorBtn.setData("decorate");

        electionsController.bind(decoratorsCombo, applyDecoratorBtn);

        Button removeDecoratorBtn = new Button(decoratorsActions, SWT.NONE);
        removeDecoratorBtn.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        removeDecoratorBtn.setText("Quitar decoradores");
        removeDecoratorBtn.setData("dedecorate");

        electionsController.bind(removeDecoratorBtn);

        Group observersActions = new Group(actionsContainer, SWT.NONE);
        observersActions.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
        observersActions.setLayout(new GridLayout());
        observersActions.setText("OBSERVADORES");

        Combo observersCombo = new Combo(observersActions, SWT.READ_ONLY);
        observersCombo.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        observersCombo.setItems("Cambios en los resultados", "Nuevo partido en cabeza");
        observersCombo.select(0);

        Button applyObserverBtn = new Button(observersActions, SWT.NONE);
        applyObserverBtn.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        applyObserverBtn.setText("Aplicar observador");
        applyObserverBtn.setData("attach");

        electionsController.bind(observersCombo, applyObserverBtn);

        Button removeObserverBtn = new Button(observersActions, SWT.NONE);
        removeObserverBtn.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        removeObserverBtn.setText("Quitar observadores");
        removeObserverBtn.setData("detach");

        electionsController.bind(removeObserverBtn);


        // ¡El botón de editar votos no forma parte de la práctica!
        // ¡Los votos deben cargarse desde fichero!

        Button editVotesBtn = new Button(actionsContainer, SWT.NONE);
        editVotesBtn.setData("edit");
        editVotesBtn.setText("Editar votos");

        electionsController.bind(editVotesBtn);
    }

    private void updateTable(Table tableToUpdate, String results) {
        String[] splittedResults = results.split("\n");

        tableToUpdate.removeAll();

        String resultsString = String.join("\n",
                Arrays.copyOfRange(splittedResults, 1, splittedResults.length - 2));

        List<List<String>> resultsData = new ArrayList<List<String>>();

        for (String resultsLine : resultsString.split("\n")) {
            String[] splittedLine = resultsLine.split("\t");
            for (int i = 0; i < splittedLine.length; i++) {
                if (i == resultsData.size()) {
                    resultsData.add(new ArrayList<String>());
                }

                resultsData.get(i).add(splittedLine[i]);
            }
        }

        for (TableColumn column : tableToUpdate.getColumns()) {
            column.dispose();
        }

        for (int i = 0; i < splittedResults.length - 2; i++) {
            new TableColumn(tableToUpdate, SWT.NONE).setWidth(100);
        }

        boolean coloredTable = this.isAColor(resultsData.get(0).get(0));

        int startingIndex = coloredTable ? 1 : 0;

        tableToUpdate.layout();

        TableItem tableItem;
        for (int i = startingIndex; i < resultsData.size(); i++) {
            tableItem = new TableItem(tableToUpdate, SWT.NONE);

            for (int j = 0; j < resultsData.get(i).size(); j++) {
                tableItem.setText(j, resultsData.get(i).get(j));
                if (coloredTable) {
                    tableItem.setBackground(j, this.colorStringToSWTColor(resultsData.get(0).get(j)));
                }
            }
        }

        new TableItem(tableToUpdate, SWT.NONE);

        TableItem emptiesItem = new TableItem(tableToUpdate, SWT.NONE);
        emptiesItem.setText(splittedResults[splittedResults.length - 2]);

        TableItem nullsItem = new TableItem(tableToUpdate, SWT.NONE);
        nullsItem.setText(splittedResults[splittedResults.length - 1]);

        for (TableColumn column : tableToUpdate.getColumns()) {
            column.pack();
        }
    }

    public void showResults(String results) {
        this.selectionResultsGroup.setText("RESULTADOS DE " + results.split("\n")[0].trim());

        this.updateTable(this.selectionResults, results);

        this.selectionResultsGroup.layout();
        this.resultsContainer.layout();
    }

    public void showResults(Table table, String results) {
        this.updateTable(table, results);

        // Set the contentComposite as the content for the ScrolledComposite
        this.scrollableContainer.setContent(this.observersContainer);

        // Adjust the contentComposite's size dynamically
        this.observersContainer.pack();
        this.scrollableContainer.setMinSize(this.observersContainer.computeSize(SWT.DEFAULT, SWT.DEFAULT));

    }

    public Table addTable(String label) {
        new Label(this.observersContainer, SWT.NONE).setText(label);
        Table table = new Table(this.observersContainer, SWT.BORDER);

        table.setLinesVisible(true);
        table.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));

        ScrollBar horizontal = this.observersContainer.getHorizontalBar();
        ScrollBar vertical = this.observersContainer.getVerticalBar();

        if (horizontal != null) {
            horizontal.setVisible(true);
        }

        if (vertical != null) {
            vertical.setVisible(true);
        }

        return table;
    }

    public void removeTable(Table table) {
        Control lastWidget = null;
        for(Control widget : table.getParent().getChildren()) {
            if(widget == table) {
                lastWidget.dispose();
            }
            lastWidget = widget;
        }

        table.dispose();

        // Set the contentComposite as the content for the ScrolledComposite
        this.scrollableContainer.setContent(this.observersContainer);

        // Adjust the contentComposite's size dynamically
        this.observersContainer.pack();
        this.scrollableContainer.setMinSize(this.observersContainer.computeSize(SWT.DEFAULT, SWT.DEFAULT));
    }

    @Override
    protected void checkSubclass() {
    }

    private Color colorStringToSWTColor(String color) {
        Color swtColor;

        switch (color) {
            case "BLUE":
                swtColor = new Color(this.getDisplay(), 160, 225, 255);
                break;
            case "GREEN":
                swtColor = new Color(this.getDisplay(), 155, 225, 160);
                break;
            case "ORANGE":
                swtColor = new Color(this.getDisplay(), 240, 200, 125);
                break;
            case "PURPLE":
                swtColor = new Color(this.getDisplay(), 215, 160, 255);
                break;
            case "RED":
                swtColor = new Color(this.getDisplay(), 235, 120, 115);
                break;
            case "YELLOW":
                swtColor = new Color(this.getDisplay(), 240, 240, 135);
                break;
            default:
                swtColor = new Color(this.getDisplay(), 160, 225, 255);
        }

        return swtColor;
    }

    private boolean isAColor(String word) {
        boolean isAColor = false;

        int i = 0;
        while (!isAColor && i < es.unileon.prg2.elections.Color.values().length) {
            if (es.unileon.prg2.elections.Color.values()[i].toString().equals(word)) {
                isAColor = true;
            }
            i++;
        }

        return isAColor;
    }
}
