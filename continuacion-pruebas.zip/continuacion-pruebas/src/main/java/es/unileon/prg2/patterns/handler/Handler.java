package es.unileon.prg2.patterns.handler;

public interface Handler {

	String toString();
	int compareTo (Handler another);
	
}
