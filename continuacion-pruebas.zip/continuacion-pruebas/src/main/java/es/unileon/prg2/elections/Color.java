package es.unileon.prg2.elections;

public enum Color {

    BLUE, GREEN, ORANGE, PURPLE, RED, YELLOW;

}
