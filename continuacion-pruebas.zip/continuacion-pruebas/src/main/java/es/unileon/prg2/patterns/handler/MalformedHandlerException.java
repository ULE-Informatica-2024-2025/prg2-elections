package es.unileon.prg2.patterns.handler;

public class MalformedHandlerException extends Exception {
	
	public MalformedHandlerException (String msg){
		super(msg);
	}

}
