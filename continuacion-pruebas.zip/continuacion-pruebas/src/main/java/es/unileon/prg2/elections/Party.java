package es.unileon.prg2.elections;

import java.awt.Color;

import es.unileon.prg2.patterns.handler.Handler;
import es.unileon.prg2.patterns.handler.Name;

public class Party {

    private String name;
    private Color color;
    private int votes;

    public Party(String name, Color partyColor){
        this.name = name;
        this.color = Color.WHITE;
    }

    public String getName(){
        return name;
    }

    public Color getColor(){
        return this.color;
    }

    public int getVotes(){
        return this.votes;
    }

    public void setVotes(int i) {
        this.votes=votes;
    }

}
