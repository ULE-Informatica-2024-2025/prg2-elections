package es.unileon.prg2.patterns.observer;

public interface Observable {

    void attach(Observer observer);

    void detach();

    void noti();

}
