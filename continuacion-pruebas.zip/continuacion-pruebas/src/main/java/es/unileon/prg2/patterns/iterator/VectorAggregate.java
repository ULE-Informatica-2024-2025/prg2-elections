package es.unileon.prg2.patterns.iterator;

import java.util.Vector;

public class VectorAggregate<T> extends Vector<T> implements Aggregate<T> {

    public Iterator<T> createIterator() {
        return new ListIterator<T>(this);
    }

    public Iterator<T> createIterator(String type) {
        if (type.equals("queue"))
            return new QueueIterator<T>(this);
        else
            return new ListIterator<T>(this);
    }

    public int getSize() {
        return size();
    }

    public T get(int index) {
        return elementAt(index);
    }

}
