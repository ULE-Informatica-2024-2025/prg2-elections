package es.unileon.prg2.elections;

import org.eclipse.swt.widgets.Display;

import es.unileon.prg2.patterns.composite.ElectionException;
import es.unileon.prg2.elections.controllers.ElectionsController;

public class MainElections {

    public static void main(String[] args) throws ElectionException {
        Elections elections = null;

        elections = new Elections("Nodo raíz", "src/main/resources/Elecciones2022CyL_partidosYprocuradores.csv",
                    "src/main/resources/Elecciones2022CyL_censo.csv");


        Display display = new Display();

        ElectionsController electionsController = new ElectionsController(elections, display);

        electionsController.openUI();

        while (!electionsController.isUIDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }

        display.dispose();
    }
}
