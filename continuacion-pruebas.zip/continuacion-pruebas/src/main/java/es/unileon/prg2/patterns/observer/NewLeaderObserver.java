package es.unileon.prg2.patterns.observer;

import es.unileon.prg2.elections.Parties;
import es.unileon.prg2.elections.Party;
import es.unileon.prg2.elections.controllers.ElectionsController;
import es.unileon.prg2.patterns.composite.ElectionComponent;
import es.unileon.prg2.patterns.decorator.Results;
import es.unileon.prg2.patterns.iterator.Iterator;

public class NewLeaderObserver implements Observer {

    private ElectionComponent observedNode;
    private ElectionsController controller;

    private Party leader;

    public NewLeaderObserver(ElectionComponent observedNode, ElectionsController controller) {
        this.observedNode = observedNode;
        this.controller = controller;
    }

    @Override
    public void update() {
        // TO DO
    }
}
