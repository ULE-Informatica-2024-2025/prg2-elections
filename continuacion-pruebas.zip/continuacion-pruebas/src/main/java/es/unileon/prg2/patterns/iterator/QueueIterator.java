package es.unileon.prg2.patterns.iterator;

public class QueueIterator<T> implements Iterator<T> {

    private Aggregate<T> aggregate;
    private int current;

    public QueueIterator(Aggregate<T> aggregate) {
        this.aggregate = aggregate;
        current = aggregate.getSize() - 1;
    }

    public void firstElement() {
        current = aggregate.getSize() - 1;
    }

    public void nextElement() {
        current = current - 1;
    }

    public boolean hasMoreElements() {
        return current >= 0;
    }

    public T currentElement() {
        return aggregate.get(current);
    }

    @Override
    public boolean hasNext() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'hasNext'");
    }

    @Override
    public T next() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'next'");
    }

}
