package es.unileon.prg2.elections;

public class ElectionException extends Exception {
    public ElectionException(String message) {
        super(message);
    }
}
