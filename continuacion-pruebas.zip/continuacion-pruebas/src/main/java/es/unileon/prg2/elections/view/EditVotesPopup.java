package es.unileon.prg2.elections.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import es.unileon.prg2.elections.Parties;
import es.unileon.prg2.elections.Party;
import es.unileon.prg2.elections.controllers.ElectionsController;
import es.unileon.prg2.patterns.decorator.Results;
import es.unileon.prg2.patterns.iterator.Iterator;

public class EditVotesPopup extends Shell {

    public EditVotesPopup(Shell parent, ElectionsController controller, Results results) {
        super(parent, SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);

        this.setText("Editar votos");
        this.setSize(400, 300);
        this.setLayout(new GridLayout(1, false));

        ScrolledComposite scrolledComposite = new ScrolledComposite(this, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
        scrolledComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

        // Create a composite to hold the content
        Composite content = new Composite(scrolledComposite, SWT.NONE);
        content.setLayout(new GridLayout(2, false)); // 2 columns: labels and text fields

        List<Text> textFields = new ArrayList<Text>();

        Parties parties = results.getParties();

        Iterator<Party> iterator = parties.createIterator();

        while(iterator.hasMoreElements()) {
            new Label(content, SWT.NONE).setText(iterator.currentElement().getName() + ":");
            Text votes = new Text(content, SWT.BORDER);
            votes.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true));
            votes.setData(iterator.currentElement());
            votes.setText(String.valueOf(results.getVotes(iterator.currentElement())));
            textFields.add(votes);

            iterator.nextElement();
        }

        new Label(content, SWT.NONE).setText("Nulos:");
        Text nulls = new Text(content, SWT.BORDER);
        nulls.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true));
        nulls.setText(String.valueOf(results.getNulls()));

        new Label(content, SWT.NONE).setText("Blancos:");
        Text empties = new Text(content, SWT.BORDER);
        empties.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true));
        empties.setText(String.valueOf(results.getEmpties()));

        Button saveButton = new Button(content, SWT.PUSH);
        saveButton.setText("Guardar");
        saveButton.setData("save");
        saveButton.setLayoutData(new GridData(SWT.END, SWT.CENTER, true, false, 2, 1));

        // controller.bind(saveButton, results);

        saveButton.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                for(Text textField : textFields) {
                    results.setVotes((Party) textField.getData(), Integer.parseInt(textField.getText()));
                }

                results.setNulls(Integer.parseInt(nulls.getText()));
                results.setEmpties(Integer.parseInt(empties.getText()));

                controller.requestRecount();

                saveButton.getShell().close();
            }
        });

        Button closeButton = new Button(content, SWT.PUSH);
        closeButton.setText("Cerrar");
        closeButton.setLayoutData(new GridData(SWT.END, SWT.CENTER, true, false, 2, 1));
        closeButton.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                closeButton.getShell().close();
            }
        });

        // Adjust the size of the content to fit the children
        content.setSize(content.computeSize(SWT.DEFAULT, SWT.DEFAULT));

        // Set the content of the ScrolledComposite
        scrolledComposite.setContent(content);
        scrolledComposite.setExpandHorizontal(true);
        scrolledComposite.setExpandVertical(true);
        scrolledComposite.setMinSize(content.computeSize(SWT.DEFAULT, SWT.DEFAULT));

        this.open();

        // Keep the popup running
        Display display = parent.getDisplay();
        while (!this.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
    }

    @Override
    protected void checkSubclass() {
    }
}
