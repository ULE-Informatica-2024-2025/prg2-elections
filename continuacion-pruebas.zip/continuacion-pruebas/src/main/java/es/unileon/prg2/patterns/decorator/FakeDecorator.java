package es.unileon.prg2.patterns.decorator;

public class FakeDecorator extends Decorator {

    public FakeDecorator(Results results) {
        super(results);
    }

    public String toString() {
        String resultsToDecorate = this.results.toString();

        StringBuilder output = new StringBuilder();

        String[] linesToDecorate = resultsToDecorate.split("\n");

        for(String line : linesToDecorate) {
            output.append(line);
            output.append("\t");
            output.append("No hago nada");
            output.append("\n");
        }

        return output.toString();
    }
}
