package es.unileon.prg2.patterns.command;

import es.unileon.prg2.elections.ElectionException;
import es.unileon.prg2.elections.Elections;
import es.unileon.prg2.elections.controllers.ElectionsController;

public class CommandSaveResults implements Command {

    private Elections receiver;

    public CommandSaveResults(Elections receiver) {
        this.receiver = receiver;
    }

    public void execute(ElectionsController invoker) {
        try {
            String nodeName = invoker.getSelectedNode();
            receiver.recount(nodeName, invoker.getEditedResults());
        } catch (ElectionException e) {
            System.out.println(e.getMessage());
        }
    }

}
