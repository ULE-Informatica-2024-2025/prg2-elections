package es.unileon.prg2.patterns.builder;

import org.eclipse.swt.widgets.Tree;

import es.unileon.prg2.patterns.composite.ElectionComponent;

public interface ElectionBuilder {
    void buildLeaf(String line);
    ElectionComponent getRoot();
    Tree getTree();
}
