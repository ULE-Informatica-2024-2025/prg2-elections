package es.unileon.prg2.patterns.composite;

import es.unileon.prg2.patterns.decorator.Results;
import es.unileon.prg2.patterns.handler.Handler;
import es.unileon.prg2.patterns.iterator.Iterator;
import es.unileon.prg2.patterns.observer.Observable;
import es.unileon.prg2.patterns.observer.Observer;
import es.unileon.prg2.patterns.strategy.CountingStrategy;

public interface ElectionComponent extends Observable {

    Handler getId();

    String getNames();

    Levels getLevel();

    Results getResults();

    Results recount();

    void update(Results results);

    boolean add(ElectionComponent component) throws ElectionException;

    boolean remove(ElectionComponent component);

    ElectionComponent search(Handler id);

    void set(CountingStrategy strategy);

    void decorate(Results results);

    void removeDecorators();

    void attach(Observer observer);

    void detach();

    void noti();

    String toString();

    Iterator<ElectionComponent> createIterator();

    Iterator<ElectionComponent> createIterator(String type);

}
