package es.unileon.prg2.patterns.command;

import es.unileon.prg2.elections.ElectionException;
import es.unileon.prg2.elections.Elections;
import es.unileon.prg2.elections.controllers.ElectionsController;
import es.unileon.prg2.patterns.composite.Levels;

public class CommandGetResultsToEdit implements Command {

    private Elections receiver;

    public CommandGetResultsToEdit(Elections receiver) {
        this.receiver = receiver;
    }

    public void execute(ElectionsController invoker) {
        try {
            String nodeName = invoker.getSelectedNode();
            if(this.receiver.search(nodeName).getLevel() == Levels.LEAF) {
                invoker.showPopup(this.receiver.getResults(nodeName));
            }
        } catch (ElectionException e) {
            System.out.println(e.getMessage());
        }
    }

}
